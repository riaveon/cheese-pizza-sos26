#include <IRremote.hpp>

const int IR_RECEIVE_PIN = 11;

// Motor A (Left) - Direction pins
const int in1 = 4;
const int in2 = 5;

// Motor B (Right) - Direction pins
const int in3 = 7;
const int in4 = 8;

// Ultrasonic Sensor Pins (No extra library needed!)
const int trigPin = 9;
const int echoPin = 10;

// Only OK command is used now
const unsigned long OK_COMMAND = 0x40;

// Distance threshold to stop in centimeters (adjust as needed)
const int STOP_DISTANCE_CM = 5; 

void setup() {
  Serial.begin(9600);
  
  pinMode(in1, OUTPUT);
  pinMode(in2, OUTPUT);
  pinMode(in3, OUTPUT);
  pinMode(in4, OUTPUT);

  // Ultrasonic pins
  pinMode(trigPin, OUTPUT);
  pinMode(echoPin, INPUT);

  IrReceiver.begin(IR_RECEIVE_PIN, ENABLE_LED_FEEDBACK);

  Serial.println("SYSTEM BOOTED/READY");
}

void loop() {
  if (IrReceiver.decode()) {
    unsigned long cmd = IrReceiver.decodedIRData.command;
    
    Serial.print("Received Command: 0x");
    Serial.println(cmd, HEX);

    // Only respond to the OK command
    if (cmd == OK_COMMAND) {
      Serial.println("Executing: Move Forward (Timed + Ultrasonic)");
      executeMovementSequence();
    } 

    Serial.println("Finished command, resuming IR...");
    IrReceiver.resume();
  }
}

void executeMovementSequence() {
  // --- STEP 1: TIMED MOVEMENT (~0.95 yards) ---
  // ----------------------------------------------------
  // TODO: CALIBRATE THIS VALUE! Adjust 3500ms to hit ~0.95 yards.
  int calibrationTimeMs = 1000; 
  // ----------------------------------------------------

  Serial.println("-> Phase 1: Moving forward by timer...");
  moveMotorsForward();
  delay(calibrationTimeMs);

  // --- STEP 2: ULTRASONIC PRECISION APPROACH ---
  Serial.println("-> Phase 2: Ultrasonic sensor active, looking for object...");
  
  // Keep moving forward until the distance is less than or equal to STOP_DISTANCE_CM
  while (getDistanceCm() > STOP_DISTANCE_CM) {
    moveMotorsForward();
    // Small delay to prevent spamming the sensor too fast
    delay(50); 
  }

  // Object reached or close enough - Stop motors!
  stopMotors();
  Serial.println("-> Target reached! Motors OFF.");
}

void moveMotorsForward() {
  digitalWrite(in1, HIGH);
  digitalWrite(in2, LOW);
  digitalWrite(in3, HIGH);
  digitalWrite(in4, LOW);
}

void stopMotors() {
  digitalWrite(in1, LOW);
  digitalWrite(in2, LOW);
  digitalWrite(in3, LOW);
  digitalWrite(in4, LOW);
}

// Helper function to get distance from HC-SR04 without libraries
long getDistanceCm() {
  // Clear the trigPin
  digitalWrite(trigPin, LOW);
  delayMicroseconds(2);

  // Set the trigPin on HIGH for 10 microseconds
  digitalWrite(trigPin, HIGH);
  delayMicroseconds(10);
  digitalWrite(trigPin, LOW);

  // Read the echoPin, returns the sound wave travel time in microseconds
  long duration = pulseIn(echoPin, HIGH);

  // Calculate the distance (speed of sound is ~0.034 cm/us, divide by 2 for round trip)
  long distanceCm = duration * 0.034 / 2;

  return distanceCm;
}