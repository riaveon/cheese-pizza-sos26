#include <IRremote.hpp>

const int IR_RECEIVE_PIN = 11;

// Motor A (Left) - Only direction pins needed now!
const int in1 = 4;
const int in2 = 5;

// Motor B (Right)
const int in3 = 7;
const int in4 = 8;

const unsigned long UP_COMMAND = 0x46;
const unsigned long OK_COMMAND = 0x40;
const unsigned long DOWN_COMMAND = 0x15;

void setup() {
  Serial.begin(9600);
  
  pinMode(in1, OUTPUT);
  pinMode(in2, OUTPUT);
  pinMode(in3, OUTPUT);
  pinMode(in4, OUTPUT);

  IrReceiver.begin(IR_RECEIVE_PIN, ENABLE_LED_FEEDBACK);

  Serial.println("SYSTEM BOOTED/READY");
}

void loop() {
  if (IrReceiver.decode()) {
    unsigned long cmd = IrReceiver.decodedIRData.command;
    
    Serial.print("Received Command: 0x");
    Serial.println(cmd, HEX);

    if (cmd == UP_COMMAND) {
      Serial.println("Executing: Move Forward (Short)");
      moveForward(100); // Adjust duration (ms) for ~1 inch
    } 
    else if (cmd == OK_COMMAND) {
      Serial.println("Executing: Move Forward (Long)");
      moveForward(3600); // Adjust duration (ms) for ~1 yard
    } 
    else if (cmd == DOWN_COMMAND) {
      Serial.println("Executing: Move Backward");
      moveBackward(100);
    }

    Serial.println("Finished command, resuming IR...");
    IrReceiver.resume();
  }
}

void moveForward(int durationMs) {
  Serial.println("-> Motors ON (Forward)");
  
  digitalWrite(in1, HIGH);
  digitalWrite(in2, LOW);
  digitalWrite(in3, HIGH);
  digitalWrite(in4, LOW);

  delay(durationMs);

  Serial.println("-> Motors OFF");
  digitalWrite(in1, LOW);
  digitalWrite(in2, LOW);
  digitalWrite(in3, LOW);
  digitalWrite(in4, LOW);
}

void moveBackward(int durationMs) {
  Serial.println("-> Motors ON (Backward)");
  
  digitalWrite(in1, LOW);
  digitalWrite(in2, HIGH);
  digitalWrite(in3, LOW);
  digitalWrite(in4, HIGH);

  delay(durationMs);

  Serial.println("-> Motors OFF");
  digitalWrite(in1, LOW);
  digitalWrite(in2, LOW);
  digitalWrite(in3, LOW);
  digitalWrite(in4, LOW);
}